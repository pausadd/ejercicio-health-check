<?php
$myhostname = gethostname();
echo "<center><h1>Current POD:" . $myhostname . "</center></h1>";
phpinfo();
?>
