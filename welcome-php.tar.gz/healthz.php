<?php
$data = [ 'health' => 'good' ];
echo json_encode( $data );
http_response_code(200);
?>
